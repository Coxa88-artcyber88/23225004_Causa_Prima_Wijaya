#include <iostream>
#include <string>

class RekeningBank {
private:
    double saldo;

public:
    RekeningBank(double saldo_awal) {
        saldo = saldo_awal;
        std::cout << "Rekening dibuat dengan saldo awal: Rp" << saldo << std::endl;
    }

    void setor(double jumlah) {
        if (jumlah > 0) {
            saldo += jumlah;
            std::cout << "Setor Rp" << jumlah << " berhasil. Saldo sekarang: Rp" << saldo << std::endl;
        } else {
            std::cout << "Jumlah setor harus positif!" << std::endl;
        }
    }

    void tarik(double jumlah) {
        if (jumlah <= 0) {
            std::cout << "Jumlah tarik harus positif!" << std::endl;
        }
        else if (jumlah > saldo) {
            std::cout << "Penarikan Gagal! Saldo tidak mencukupi." << std::endl;
            std::cout << "Saldo Anda: Rp" << saldo << ", jumlah tarik: Rp" << jumlah << std::endl;
        }
        else {
            saldo -= jumlah;
            std::cout << "Tarik Rp" << jumlah << " berhasil. Sisa saldo: Rp" << saldo << std::endl;
        }
    }

    void cekSaldo() {
        std::cout << "Saldo saat ini: Rp" << saldo << std::endl;
    }
};

int main() {
    RekeningBank rekeningSaya(1000000);
    
    std::cout << "\n=== Transaksi Setor ===" << std::endl;
    rekeningSaya.setor(500000);
    
    std::cout << "\n=== Transaksi Tarik (Cukup Saldo) ===" << std::endl;
    rekeningSaya.tarik(300000);
    
    std::cout << "\n=== Transaksi Tarik (Saldo Kurang) ===" << std::endl;
    rekeningSaya.tarik(2000000);
    
    std::cout << "\n=== Cek Saldo Akhir ===" << std::endl;
    rekeningSaya.cekSaldo();
    
    return 0;
}
