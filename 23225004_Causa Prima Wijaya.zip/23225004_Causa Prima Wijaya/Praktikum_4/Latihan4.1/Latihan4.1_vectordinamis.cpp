#include <iostream>
#include <vector>

int main() {  
    std::vector<int> kumpulan_angka;

    std::cout << "=== EKSPLORASI VECTOR ===" << std::endl;

    std::cout << "\n[1] Menambah data dengan push_back:" << std::endl;
    kumpulan_angka.push_back(10);  
    kumpulan_angka.push_back(25);  
    kumpulan_angka.push_back(50);
    
    for(int i = 0; i < kumpulan_angka.size(); i++) {  
        std::cout << "Data ke-" << i << ": " << kumpulan_angka[i] << 
std::endl;  
    }  
    std::cout << "Ukuran vector: " << kumpulan_angka.size() << 
std::endl;

    std::cout << "\n[2] Setelah pop_back (hapus elemen terakhir):" << 
std::endl;
    kumpulan_angka.pop_back();
    
    for(int i = 0; i < kumpulan_angka.size(); i++) {  
        std::cout << "Data ke-" << i << ": " << kumpulan_angka[i] << 
std::endl;  
    }  
    std::cout << "Ukuran vector: " << kumpulan_angka.size() << 
std::endl;

    std::cout << "\n[3] Setelah clear (hapus semua elemen):" << 
std::endl;
    kumpulan_angka.clear();
    
    std::cout << "Ukuran vector setelah clear: " << 
kumpulan_angka.size() << std::endl;
    
    if(kumpulan_angka.empty()) {
        std::cout << "Vector kosong!" << std::endl;
    }

    std::cout << "\n[4] Menambah data lagi setelah clear:" << std::endl;
    kumpulan_angka.push_back(100);
    kumpulan_angka.push_back(200);
    
    for(int i = 0; i < kumpulan_angka.size(); i++) {  
        std::cout << "Data ke-" << i << ": " << kumpulan_angka[i] << 
std::endl;  
    }  
    std::cout << "Ukuran vector: " << kumpulan_angka.size() << 
std::endl;

    std::cout << "\n=== SELESAI ===" << std::endl;
      
    return 0;  
}
