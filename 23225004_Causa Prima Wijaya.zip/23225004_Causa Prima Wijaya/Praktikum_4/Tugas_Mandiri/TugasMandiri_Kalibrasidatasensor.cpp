#include <iostream>
#include <fstream>
#include <vector>

int main() {
    // 1. INISIALISASI STRUKTUR DATA
    std::vector<double> sensor;
    
    // 2. PENGISIAN DATA AWAL (push_back)
    sensor.push_back(100.5);
    sensor.push_back(200.0);
    sensor.push_back(150.5);
    
    // Tampilkan data awal
    std::cout << "=== DATA SENSOR AWAL ===" << std::endl;
    for (int i = 0; i < sensor.size(); i++) {
        std::cout << "Sensor[" << i << "] = " << sensor[i] << std::endl;
    }
    
    // 3. PROSES KALIBRASI (Batch Processing)
    std::cout << "\n--- PROSES KALIBRASI 10% ---" << std::endl;
    for (int i = 0; i < sensor.size(); i++) {
        double nilai_lama = sensor[i];
        sensor[i] = sensor[i] * 1.1; // Kalibrasi +10%
        std::cout << "Sensor[" << i << "]: " << nilai_lama << " -> " << sensor[i] << std::endl;
    }
    
    // 4. PENYIMPANAN KE FILE EKSTERNAL
    std::ofstream fileHasil("hasil_kalibrasi.txt");
    
    if (fileHasil.is_open()) {
        // 5. MENULIS HASIL KE FILE
        for (int i = 0; i < sensor.size(); i++) {
            fileHasil << sensor[i] << std::endl; // Setiap nilai di baris terpisah
        }
        
        // 6. MENUTUP FILE
        fileHasil.close();
        
        std::cout << "\n=> Hasil kalibrasi tersimpan di 'hasil_kalibrasi.txt'" << std::endl;
    } else {
        std::cout << "\nERROR: Gagal membuat file hasil_kalibrasi.txt!" << std::endl;
        return 1;
    }
    
    // Verifikasi dengan membaca file yang baru dibuat
    std::cout << "\n--- VERIFIKASI ISI FILE ---" << std::endl;
    std::ifstream fileBaca("hasil_kalibrasi.txt");
    std::string baris;
    int idx = 0;
    
    if (fileBaca.is_open()) {
        while (std::getline(fileBaca, baris)) {
            std::cout << "Baris " << idx+1 << ": " << baris << std::endl;
            idx++;
        }
        fileBaca.close();
    }
    
    std::cout << "\n=== SELESAI ===" << std::endl;
    
    return 0;
}