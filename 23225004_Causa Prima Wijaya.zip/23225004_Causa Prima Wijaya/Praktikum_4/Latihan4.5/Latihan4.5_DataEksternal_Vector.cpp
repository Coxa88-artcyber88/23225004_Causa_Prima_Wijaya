#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>  // Pustaka fungsi matematika (std::sqrt)
#include <string> // Pustaka string untuk membaca teks header

// 1. Blueprint Objek  
class Partikel {  
private:  
    double x, y;  
    double jarak_pusat;

public:
    Partikel(double pos_x, double pos_y) {  
        x = pos_x;
        y = pos_y;
        jarak_pusat = 0.0;
    }

    // EKSPLORASI 2: Fungsi hitung jarak terhadap titik acuan (5.0, 5.0)
    void hitungJarak() {
        // Versi awal: jarak_pusat = std::sqrt((x * x) + (y * y));
        // Versi baru: jarak terhadap titik (5.0, 5.0)
        jarak_pusat = std::sqrt(((x - 5.0) * (x - 5.0)) + ((y - 5.0) * (y - 5.0)));
    }  

    // Getter untuk akses data private (dibutuhkan saat menulis file)
    double getX() { return x; }
    double getY() { return y; }
    double getJarak() { return jarak_pusat; }
};

int main() {  
    // A. FASE I/O BACA
    std::vector<Partikel> kumpulan_partikel;  
    std::ifstream fileBaca("koordinat_mentah.txt");  
      
    std::string header1, header2; // Variabel sementara penampung teks  
    double temp_x, temp_y;

    std::cout << "=== EKSPLORASI FILE DAN VEKTOR ===" << std::endl;
    std::cout << "Membaca file 'koordinat_mentah.txt'..." << std::endl;

    if (fileBaca.is_open()) {
        
        fileBaca >> header1 >> header2;
        std::cout << "Header file: " << header1 << " " << header2 << std::endl;

        int baris = 0;
        while (fileBaca >> temp_x >> temp_y) {   
            kumpulan_partikel.push_back(Partikel(temp_x, temp_y));
            baris++;
        }  
        fileBaca.close();  
        std::cout << "Jumlah partikel terbaca: " << baris << std::endl;
    } else {  
        std::cout << "Gagal! Pastikan file koordinat_mentah.txt sudah Anda buat." << std::endl;  
        std::cout << "\nPetunjuk: Buat file 'koordinat_mentah.txt' dengan format:" << std::endl;
        std::cout << "X Y (sebagai header)" << std::endl;
        std::cout << "1.0 2.0" << std::endl;
        std::cout << "3.0 4.0" << std::endl;
        std::cout << "dst..." << std::endl;
        return 1; // Menghentikan program jika file tidak ada  
    }

    // B. FASE KOMPUTASI (Batch Processing)  
    std::cout << "\nMemproses " << kumpulan_partikel.size() << " partikel..." << std::endl;
    std::cout << "Menghitung jarak terhadap titik acuan (5.0, 5.0)" << std::endl;
    
    for (int i = 0; i < kumpulan_partikel.size(); i++) {  
        kumpulan_partikel[i].hitungJarak();  
    }

    // C. FASE I/O TULIS
    std::ofstream fileHasil("hasil_jarak.txt");  
    if (fileHasil.is_open()) {  
        fileHasil << "Partikel\tPosisi X\tPosisi Y\tJarak ke (5.0,5.0)" << std::endl;
        
        for (int i = 0; i < kumpulan_partikel.size(); i++) {  
            fileHasil << i + 1 << "\t\t" 
                      << kumpulan_partikel[i].getX() << "\t\t" 
                      << kumpulan_partikel[i].getY() << "\t\t" 
                      << kumpulan_partikel[i].getJarak() << std::endl;  
        }  
        fileHasil.close();  
        std::cout << "\n=> Selesai! Buka file 'hasil_jarak.txt' untuk melihat kalkulasinya." << std::endl;  
    } else {
        std::cout << "Gagal membuat file hasil!" << std::endl;
    }

    // Tampilkan preview di terminal
    std::cout << "\n--- PREVIEW 5 DATA PERTAMA ---" << std::endl;
    int preview = (kumpulan_partikel.size() < 5) ? kumpulan_partikel.size() : 5;
    for (int i = 0; i < preview; i++) {
        std::cout << "Partikel " << i+1 << ": (" 
                  << kumpulan_partikel[i].getX() << ", " 
                  << kumpulan_partikel[i].getY() << ") | Jarak: " 
                  << kumpulan_partikel[i].getJarak() << std::endl;
    }

    std::cout << "\n=== SELESAI ===" << std::endl;

    return 0;  
}