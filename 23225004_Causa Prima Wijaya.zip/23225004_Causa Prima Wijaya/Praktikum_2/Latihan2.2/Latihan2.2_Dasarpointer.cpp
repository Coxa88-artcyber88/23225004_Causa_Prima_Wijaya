#include <iostream>

int main() {  
    int angka = 100;  
    int *ptr_angka = &angka;

    std::cout << "Nilai variabel angka: " << angka << std::endl;  
    std::cout << "Alamat memori angka (&angka): " << &angka << 
std::endl;  
    std::cout << "Isi dari pointer ptr_angka: " << ptr_angka << 
std::endl;  
    std::cout << "Nilai yang ditunjuk pointer (*ptr_angka): " << 
*ptr_angka << std::endl;

    // EKSPLORASI: Memanipulasi nilai melalui pointer
    *ptr_angka = 500;
    
    std::cout << "\n--- SETELAH DIUBAH MELALUI POINTER ---" << 
std::endl;
    std::cout << "Nilai variabel angka sekarang: " << angka << 
std::endl;  
    std::cout << "Nilai yang ditunjuk pointer (*ptr_angka): " << 
*ptr_angka << std::endl;

    return 0;  
}
