#include <iostream>

int main() {  
    const int ukuran = 6; 
      
    int vektorA[ukuran] = {1, 2, 3, 4, 5};
    int vektorB[ukuran] = {10, 20, 30, 40, 50};
    int hasil[ukuran];

    for(int i = 0; i < ukuran; i++) {  
        hasil[i] = vektorA[i] + vektorB[i];  
        std::cout << "Elemen indeks ke-" << i << ": " << hasil[i] << std::endl;  
    }  
      
    return 0;  
}