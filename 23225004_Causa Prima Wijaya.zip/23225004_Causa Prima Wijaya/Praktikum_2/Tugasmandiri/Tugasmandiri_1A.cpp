#include <iostream>

// Fungsi untuk menghitung rata-rata array 1D
double hitungRataRata(double arr[], int ukuran) {
    double total = 0.0;
    
    // Menghitung total akumulasi seluruh elemen
    for(int i = 0; i < ukuran; i++) {
        total += arr[i];
    }
    
    // Mengembalikan nilai rata-rata
    return total / ukuran;
}

int main() {
    // Array berisi 5 angka sembarang
    double data[] = {12.5, 24.0, 36.5, 48.0, 55.5};
    int ukuran = sizeof(data) / sizeof(data[0]); // Menghitung ukuran array otomatis
    
    // Memanggil fungsi hitungRataRata
    double rata = hitungRataRata(data, ukuran);
    
    // Menampilkan hasil
    std::cout << "Data array: ";
    for(int i = 0; i < ukuran; i++) {
        std::cout << data[i] << " ";
    }
    std::cout << std::endl;
    
    std::cout << "Ukuran array: " << ukuran << std::endl;
    std::cout << "Rata-rata: " << rata << std::endl;
    
    return 0;
}