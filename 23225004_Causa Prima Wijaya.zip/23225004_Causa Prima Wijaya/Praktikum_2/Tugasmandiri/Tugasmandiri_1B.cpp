#include <iostream>

void kuadratkan(int *val) {
    *val = (*val) * (*val);
}

int main() {
    int angka = 5;
    
    std::cout << "Nilai awal angka: " << angka << std::endl;
    kuadratkan(&angka);
    std::cout << "Nilai angka setelah kuadrat: " << angka << std::endl;
    
    return 0;
}
