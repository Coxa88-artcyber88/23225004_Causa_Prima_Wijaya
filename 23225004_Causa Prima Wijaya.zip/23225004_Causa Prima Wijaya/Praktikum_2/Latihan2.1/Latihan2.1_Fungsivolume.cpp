#include <iostream>

// EKSPLORASI: Fungsi diubah menjadi void (tidak mengembalikan nilai)
void hitungVolumeBalok(double panjang, double lebar, double tinggi) {
    double hasil = panjang * lebar * tinggi; // Menghitung volume
    std::cout << "Volume balok: " << hasil << std::endl; // Mencetak langsung dari dalam fungsi
    // Tidak ada return karena fungsi void
}

int main() {
    // EKSPLORASI: Memanggil fungsi tanpa menyimpan ke variabel
    hitungVolumeBalok(10.5, 5.0, 2.0);
    
    return 0;
}