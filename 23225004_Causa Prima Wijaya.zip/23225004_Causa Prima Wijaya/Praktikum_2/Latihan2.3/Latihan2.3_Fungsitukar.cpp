#include <iostream>

// Dengan reference (pass by reference) - nilai akan tertukar
void tukarNilai(int &a, int &b) {  
    int sementara = a;
    a = b;
    b = sementara;
}

int main() {  
    int x = 100, y = 500;  
      
    std::cout << "Sebelum ditukar : x = " << x << ", y = " << y << 
std::endl;  
    tukarNilai(x, y);   
    std::cout << "Setelah ditukar : x = " << x << ", y = " << y << 
std::endl;  
      
    return 0;  
}
