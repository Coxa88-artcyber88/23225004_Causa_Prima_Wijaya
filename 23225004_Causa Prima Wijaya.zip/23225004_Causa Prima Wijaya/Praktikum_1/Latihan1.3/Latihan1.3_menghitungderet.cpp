#include <iostream>

int main() {  
    int batas_atas;  
    int total_jumlah; // EKSPLORASI 3: Inisialisasi dihapus (GARBAGE VALUE!)
    
    std::cout << "Masukkan batas atas angka: ";  
    std::cin >> batas_atas;

    // EKSPLORASI 1: i = 0 (bukan 1)
    // EKSPLORASI 2: i += 2 (bukan i++)
    for (int i = 0; i <= batas_atas; i += 2) {  
        total_jumlah = total_jumlah + i; // pakai + biasa, bukan += biar jelas
    }

    std::cout << "Total penjumlahan dari 1 hingga "  
              << batas_atas  
              << " adalah: "  
              << total_jumlah << std::endl;

    return 0;  
}