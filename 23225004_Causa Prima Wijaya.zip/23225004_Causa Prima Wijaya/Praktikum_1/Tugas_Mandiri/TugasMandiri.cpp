#include <iostream>

int main() {
    int angka;
    int total_positif = 0;
    
    std::cout << "Masukkan 5 angka:\n";
    
    for (int i = 1; i <= 5; i++) {
        std::cout << "Angka ke-" << i << ": ";
        std::cin >> angka;
        
        // Cek apakah angka positif, negatif, atau nol
        if (angka > 0) {
            std::cout << "  → Positif" << std::endl;
            total_positif += angka; // Tambahkan ke total positif
        }
        else if (angka < 0) {
            std::cout << "  → Negatif" << std::endl;
        }
        else {
            std::cout << "  → Nol" << std::endl;
        }
    }
    
    std::cout << "\n======= HASIL =======" << std::endl;
    std::cout << "Jumlah total angka positif: " << total_positif << std::endl;
    
    return 0;
}