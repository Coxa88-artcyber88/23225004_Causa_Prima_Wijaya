#include <iostream>

int main() {
    double celsius, fahrenheit;
    
    std::cout << "Masukkan suhu dalam Celsius: ";
    std::cin >> celsius;
    
    fahrenheit = (9.0 / 5.0) * celsius + 32.0;
    
    std::cout << "Suhu dalam Fahrenheit: " << fahrenheit << std::endl;
    
    return 0;
}
